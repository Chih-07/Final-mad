package com.example.javamad;

public class navprofile {
}
